import { Mail, Phone } from 'lucide-react'

export default function Contact() {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-8">Contact Me</h2>
        <div className="flex justify-center space-x-8">
          <a href="mailto:savivhor7755@gmail.com" className="flex items-center text-gray-300 hover:text-white">
            <Mail className="mr-2" size={24} />
            savivhor7755@gmail.com
          </a>
          <a href="tel:+916207457123" className="flex items-center text-gray-300 hover:text-white">
            <Phone className="mr-2" size={24} />
            +91 6207457123
          </a>
        </div>
      </div>
    </section>
  )
}

