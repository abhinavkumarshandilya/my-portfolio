export default function Achievements() {
  const achievements = [
    "2024 GFG Coding university Rank 4th",
    "2024 94.41 Percentile [top 5 percent] Naukri campus Young Tarks",
    "2024 Solved 150+ coding challenges",
    "2022-23 Prepinsta Growth Manager",
    "2024 75 Percent Naukri NCET Test",
    "2024 Hacker Rank Java 5 Star"
  ]

  const certificates = [
    "Service Now CSA",
    "Service Now CAD",
    "PrepInsta Intermediate Coding",
    "PrepInsta Java With DSA",
    "Hacker Rank Software Engineer Intern",
    "PrepInsta MERN (Full Stack)",
    "MSI Project Management",
    "Linkedin Blockchain Developer"
  ]

  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">Achievements & Certifications</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-semibold mb-4">Achievements</h3>
            <ul className="list-disc list-inside">
              {achievements.map((achievement, index) => (
                <li key={index}>{achievement}</li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-4">Certifications</h3>
            <ul className="list-disc list-inside">
              {certificates.map((certificate, index) => (
                <li key={index}>{certificate}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

