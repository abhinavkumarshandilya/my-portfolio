export default function Experience() {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">Experience</h2>
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl font-semibold">PREPINSTA | Data Analytics Intern</h3>
            <p className="text-gray-400">Dec 2023 – Feb 2024 | Remote</p>
            <p>Streamlined data collection and transformation processes, which reduced manual work by 40 percent.</p>
          </div>
          <div>
            <h3 className="text-2xl font-semibold">WEBSTACK ACADEMY | MERN Stack Intern</h3>
            <p className="text-gray-400">Aug 2023 – Oct 2023 | Remote</p>
            <ul className="list-disc list-inside mt-2">
              <li>Developed a full-stack restaurant food delivery application using the MERN stack, enhancing user experience and operational efficiency.</li>
              <li>Conducted thorough testing and debugging of application features, resulting in a 30 Percent reduction in reported issues post-launch.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

