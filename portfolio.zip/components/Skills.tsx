export default function Skills() {
  const skillCategories = [
    {
      name: "Programming",
      skills: ["Python", "Java", "C++"]
    },
    {
      name: "Development",
      skills: ["HTML/CSS/JS", "ReactJS", "SQL", "NodeJS"]
    },
    {
      name: "Database & Operating System",
      skills: ["Linux", "Service Now", "MySQL", "MongoDB"]
    },
    {
      name: "VCS & Build Tools",
      skills: ["Git", "Jupiter", "VS Code", "GitHub"]
    },
    {
      name: "Cloud Services",
      skills: ["GCP (Familiar)"]
    }
  ]

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">Skills</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">{category.name}</h3>
              <ul className="list-disc list-inside">
                {category.skills.map((skill, i) => (
                  <li key={i}>{skill}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

