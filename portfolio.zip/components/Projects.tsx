import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Projects() {
  const projects = [
    {
      title: "Food Delivery Application",
      description: "MERN stack application with Redux state management and JWT authentication.",
      date: "OCT 2023",
      details: [
        "Implemented state management with Redux for improved performance and user responsiveness",
        "Collaborated with a team using Agile methodologies, participating in weekly sprints and code reviews"
      ]
    },
    {
      title: "Quiz Application",
      description: "Java-based application with MySQL database and Java Swing UI.",
      date: "Jul 2024",
      details: [
        "Enhanced user interface using Java Swing for a responsive and interactive experience",
        "Implemented features such as timer-based quizzes, scoring systems, and detailed result summaries"
      ]
    },
    {
      title: "Intelligent Vehicle Predictive Maintenance System",
      description: "Python-based system using Machine Learning and AI for predictive maintenance.",
      date: "Sep 2024",
      details: [
        "Utilized machine learning techniques to forecast maintenance needs based on real-time sensor data",
        "Achieved high predictive accuracy, estimating maintenance dates 2-3 weeks in advance"
      ]
    }
  ]

  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card key={index} className="bg-gray-700">
              <CardHeader>
                <CardTitle>{project.title}</CardTitle>
                <CardDescription>{project.date}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{project.description}</p>
                <ul className="list-disc list-inside">
                  {project.details.map((detail, i) => (
                    <li key={i}>{detail}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

