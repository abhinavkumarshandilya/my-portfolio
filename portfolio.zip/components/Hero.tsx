import { GitlabIcon as GitHub, Linkedin } from 'lucide-react'
import Image from 'next/image'

export default function Hero() {
  return (
    <section className="h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800">
      <div className="text-center">
        <div className="mb-8 flex justify-center">
          <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-white/10">
            <Image
              src="https://media.licdn.com/dms/image/v2/D5603AQFk0SKmde0jLg/profile-displayphoto-shrink_400_400/profile-displayphoto-shrink_400_400/0/1727277632883?e=1741824000&v=beta&t=slKXlGDYWf39nYPDHi7oMI8mlkr5_GSNXJvVJatROxk"
              alt="Abhinav Kumar"
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>
        <h1 className="text-5xl font-bold mb-4">Abhinav Kumar</h1>
        <p className="text-xl mb-8">Full Stack Developer & Data Analytics Enthusiast</p>
        <div className="flex justify-center space-x-4">
          <a 
            href="https://github.com/abhinavkumarshandilya" 
            className="text-gray-300 hover:text-white transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            <GitHub size={24} />
          </a>
          <a 
            href="https://www.linkedin.com/in/abhinav-kumar-84bb39255/" 
            className="text-gray-300 hover:text-white transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Linkedin size={24} />
          </a>
        </div>
      </div>
    </section>
  )
}

