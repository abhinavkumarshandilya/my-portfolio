export default function About() {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">About Me</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-semibold mb-4">Education</h3>
            <div className="mb-4">
              <h4 className="text-xl font-medium">Bachelor of Technology (Hons.) Computer Science</h4>
              <p>Maharishi Markandeshwar (Deemed to be University)</p>
              <p>September 2021 - Present | Haryana, IND</p>
              <p>Cum. CGPA: 8.05 / 10.0</p>
            </div>
            <div className="mb-4">
              <h4 className="text-xl font-medium">12th Standard</h4>
              <p>S.R.A.P College | 2019-21</p>
              <p>Percentage: 66 | BR, IND</p>
            </div>
            <div>
              <h4 className="text-xl font-medium">10th Standard</h4>
              <p>S.Shalik+2 High School | 2018-19</p>
              <p>Percentage: 72.4 | BR, IND</p>
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-4">Personal Skills</h3>
            <ul className="list-disc list-inside">
              <li>Leadership</li>
              <li>Problem Solving</li>
              <li>Communication & Creativity</li>
              <li>Time Management</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

